Boy_age = int(input("Enter age of the Boy: "))
Girl_age = int(input("Enter age of the Girl: "))

Girl_name = input("Enter name of the Girl")
Boy_name =  input("Enter name of the Boy")

if Boy_age >=21 and Girl_age>=18:
    print(f"{Girl_name} and {Boy_name} is eligible for marriage ")
else:
    print(f"{Girl_name} and {Boy_name} is not eligible for marriage")