data_1 = []
data_2 = []
for i in range(10):
    age = int(input("Enter age of Candidate : "))
    gender = input("Enter gender of (male/female): ")

    data_1.append(age)
    data_2.append(gender)
count_of_children = 0
count_of_adult = 0

for i in data_1:
    if i < 18:
        count_of_children += 1
    else:
        count_of_adult += 1

count_of_male = 0
count_of_female = 0
for i in data_2:
    if i == "male":
        count_of_male +=1
    else:
        count_of_female +=1

print(count_of_children)
print(count_of_adult)
print(count_of_male)
print(count_of_female)















