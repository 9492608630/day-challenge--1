total_bill = int(input("enter total bill amount: "))

discount_30 = 30/100*total_bill
offer_prize_1 = total_bill - discount_30

discount_50 = 50/100*total_bill
offer_prize_2 = total_bill - discount_50


if total_bill>=1000 and total_bill<=2000:
    print(f"The total amount prize is {offer_prize_1}")
elif total_bill>=2001 and total_bill<=3000:
    print(f"The total amount prize is {offer_prize_2}")
elif total_bill>=5000:
    print("you won 2500 rupees worth of bag")
else:
    print(f"Your bill amount is {total_bill}")

